---
name: heriheri-cloud
description: Manage, upload, and download files to the user's secure HeriHeriCloud VFS drive.
---

# HeriHeriCloud VFS Agent Skill

You are connected to the user's HeriHeriCloud instance. You have access to a JSON-RPC 2.0 endpoint running locally at http://127.0.0.1:8888/mcp.

## Rules of Engagement
1. **The Sandbox:** You are strictly jailed to the `AgentWorkspace`. To you, `folder_pid: 0` or `target_pid: 0` represents the root of your secure sandbox.
2. **Execution Context:** If on Windows, NEVER use `curl.exe` for JSON payloads; you must use PowerShell.
3. **STRICT ENCODING RULE:** Because the Windows terminal destroys non-ASCII characters (like Chinese), you MUST encode all non-ASCII characters in your JSON payloads using JSON Unicode escape sequences (e.g., `\u8ff7\u8def` instead of `迷路`). Never place raw Chinese characters directly into the PowerShell string literal.
4. **Discovery:** Always use the `read_vfs` tool to list folders and discover the integer `id` of files before attempting to rename, delete, or download them.
5. **Local Paths:** When using `agent_upload` or `agent_download`, use absolute local file paths. 

## Example Execution (Windows PowerShell with Escaped Unicode)

```powershell
# Notice how the Chinese name "迷路.txt" is safely escaped to \u8ff7\u8def.txt
$json = '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"rename_item","arguments":{"id":1265,"new_name":"\u8ff7\u8def.txt"}}}'
$bytes = [System.Text.Encoding]::UTF8.GetBytes($json)

Invoke-RestMethod -Uri '[http://127.0.0.1:8888/mcp](http://127.0.0.1:8888/mcp)' -Method Post -ContentType 'application/json; charset=utf-8' -Body $bytes
```

## Available Tools & Payloads

Send all POST requests to `http://127.0.0.1:8888/mcp` with header `Content-Type: application/json`.

### 1. read_vfs
List files and folders in a directory.
JSON Payload:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "read_vfs",
    "arguments": { "folder_pid": 0 }
  }
}

### 2. search_cloud
Search files inside your workspace.
JSON Payload:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "search_cloud",
    "arguments": { "query": "target_filename" }
  }
}

### 3. create_folder
Create a folder inside a directory.
JSON Payload:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "create_folder",
    "arguments": { "name": "docs", "target_pid": 0 }
  }
}

### 4. rename_item
Rename a file or folder by integer ID.
JSON Payload:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "rename_item",
    "arguments": { "id": 123, "new_name": "renamed.txt" }
  }
}

### 5. delete_item
Move an item to trash by integer ID.
JSON Payload:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "delete_item",
    "arguments": { "id": 123 }
  }
}

### 6. agent_upload
Upload a file from local OS path to cloud.
JSON Payload:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "agent_upload",
    "arguments": { "local_path": "/absolute/path/file.ext", "target_pid": 0 }
  }
}

### 7. agent_download
Download a file from cloud to local OS path.
JSON Payload:
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "agent_download",
    "arguments": { "vfs_id": 123, "local_path": "/absolute/path/save.ext" }
  }
}

## Example Curl Command

curl -X POST http://127.0.0.1:8888/mcp -H "Content-Type: application/json" -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"read_vfs","arguments":{"folder_pid":0}}}'